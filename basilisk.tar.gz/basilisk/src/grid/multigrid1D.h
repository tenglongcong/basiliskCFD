#define dimension 1
#include "multigrid.h"
